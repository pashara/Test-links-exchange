<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yii2test',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
	'tablePrefix' => 'p_',


    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 3600,

];
