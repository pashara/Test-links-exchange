<?php

namespace app\modules\projects\requirements;

use Yii;

class Avatar extends RequirementsModel
{


    public function __construct(array $config = [],$selectedItemsNames)
    {
        parent::__construct($config);
        $this->title = 'Наличие аватара';
        $this->description = 'За наличие аватара человек получает бонусные очки';
        $this->hint = 'За наличие аватара человек получает бонусные очки';
        $this->cost['RUB'] = 5.0;
        $this->name = 'avatar';
        parent::setSelected($selectedItemsNames);
    }




    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title'], 'required'],
            [['title'], 'string', 'max' => 80],
            ['description', 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('projects', 'ID'),
            'title' => Yii::t('projects', 'Title'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProjectToCategories()
    {
        return $this->hasMany(ProjectToCategories::className(), ['project_id' => 'id']);
    }

    /**
     * @inheritdoc
     * @return ProjectQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new ProjectQuery(get_called_class());
    }
}
