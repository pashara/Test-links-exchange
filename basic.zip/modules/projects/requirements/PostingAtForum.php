<?php

namespace app\modules\projects\requirements;

use Yii;

class PostingAtForum extends RequirementsModel
{


    public function __construct(array $config = [],$selectedItemsNames)
    {
        parent::__construct($config);
        $this->title = 'Постинг на форумах';
        $this->description = 'Разрешено постить только на форумах';
        $this->hint = 'Разрешено постить толкьо на форумах';
        $this->cost['RUB'] = 15.5;
        $this->name = 'postAtForum';
        $this->require = true;
        $this->defaultSelected = true;
        $this->blocked = true;
        parent::setSelected($selectedItemsNames);
    }




}
